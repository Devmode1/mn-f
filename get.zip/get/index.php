<?php
header("Content-Type: application/json; charset=UTF-8");
error_reporting(0);
$khaled = $_GET["jack"];
if($khaled !="/start"){
$get = json_decode(file_get_contents("https://api-jack.ml/name-pubg?jack=".$khaled),1);
$text = $get["jack2"];
$json =[
'BY'=>'DEV JACK',
'USER'=>'@v_p_e',
'jack'=>$text
];
echo json_encode($json,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
}
